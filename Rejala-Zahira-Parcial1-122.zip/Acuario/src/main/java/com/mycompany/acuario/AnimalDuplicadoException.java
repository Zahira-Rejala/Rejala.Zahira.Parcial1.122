package com.mycompany.acuario;

public class AnimalDuplicadoException extends RuntimeException {

    private static final String MESSAGE = "Ese animal ya existe";

    public AnimalDuplicadoException(String mensaje) {
        super(mensaje);
    }

    public AnimalDuplicadoException() {
        this(MESSAGE);
    }
}
