
package com.mycompany.acuario;

public class Peces extends Animal implements Nadador {
    private double longitudMaxima;

    public Peces(String nombre, String habitad, TipoAgua tipoAgua, double longitudMaxima) {
        super(nombre, habitad, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }
    
    public double getLongitudMaxima(){
        return longitudMaxima;
    }
    
    @Override
    public void Nadar() {
        System.out.println("Mi nombre es " + getNombre() +  " y estoy nadando");
    }

    @Override
    public String toString() {
        return super.toString() + " Caracteristica de peces{" + "longitudMaxima=" + longitudMaxima + '}';
    }
    
    
}
