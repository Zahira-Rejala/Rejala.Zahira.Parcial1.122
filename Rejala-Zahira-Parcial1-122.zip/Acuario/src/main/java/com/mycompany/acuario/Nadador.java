
package com.mycompany.acuario;

public interface Nadador {
    void Nadar();
}
