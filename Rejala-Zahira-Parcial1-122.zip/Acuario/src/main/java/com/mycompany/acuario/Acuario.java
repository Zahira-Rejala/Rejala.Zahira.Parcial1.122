package com.mycompany.acuario;

import java.util.ArrayList;
import java.util.List;

public class Acuario {

    private List<Animal> animales;

    public Acuario() {
        this.animales = new ArrayList<>();
    }

    public void noHayAnimales() {
        if (animales.isEmpty()) {
            System.out.println("No hay animales");
        }
    }

    public void agregarAnimal(Animal animal) {
        if (animales.contains(animal)) {
            throw new AnimalDuplicadoException();
        }
        animales.add(animal);

    }

    public void mostrarAnimales() {
        for (Animal a : animales) {
            System.out.println(a.toString());
        }
    }

    public void nadar() {
        noHayAnimales();
        for (Animal a : animales) {
            if (a instanceof Nadador) {
                ((Nadador) a).Nadar();
            } else {
                System.out.println("Este animal no puede nadar");
            }
        }
    }

    public void buscarAlimento() {
        noHayAnimales();
        for (Animal a : animales) {
            if (a instanceof BuscadorAlimento) {
                ((BuscadorAlimento) a).buscarAlimento();
            } else {
                System.out.println("Este animal no puede buscar alimento");
            }
        }
    }

    public List<Animal> filtrarPorTipoAgua(TipoAgua tipo) {
        List<Animal> fil = new ArrayList<>();
        for (Animal a : animales) {
            if (a.getTipoAgua() == tipo) {
                fil.add(a);
            }
        }
        return fil;
    }

    public void mostrarAnimalesPorTipo(String tipoAnimal) {
        boolean alguno = false;

        for (Animal a : animales) {
            if (tipoAnimal.equals("Peces") && a instanceof Peces) {
                System.out.println(a.toString());
                alguno = true;
            }
            if (tipoAnimal.equals("MamiferosMarinos") && a instanceof MamiferosMarinos) {
                System.out.println(a.toString());
                alguno = true;
            }
            if (tipoAnimal.equals("Crustaceos") && a instanceof Crustaceos) {
                System.out.println(a.toString());
                alguno = true;
            }
        }

        if (!alguno) {
            System.out.println("No hay animales del tipo: " + tipoAnimal);
        }
    }
}
