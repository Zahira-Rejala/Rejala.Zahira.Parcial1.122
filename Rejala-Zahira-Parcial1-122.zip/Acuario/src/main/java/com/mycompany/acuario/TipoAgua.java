
package com.mycompany.acuario;

public enum TipoAgua {
    DULCE,
    SALADA;
}
