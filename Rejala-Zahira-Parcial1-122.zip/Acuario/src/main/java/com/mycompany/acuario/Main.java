
package com.mycompany.acuario;

public class Main {

    public static void main(String[] args) {
        
        
        Acuario a = new Acuario();
        Animal pez = new Peces("Nemo", "Tanque Tropical", TipoAgua.DULCE, 20.3);
        Animal delfin = new MamiferosMarinos("Lucas", "Oceano", TipoAgua.SALADA, 51);
        Animal Pulpo = new Crustaceos("Juan", "Tierra", TipoAgua.DULCE, 8);
        Animal foca = new MamiferosMarinos("Sandra", "Oceano", TipoAgua.DULCE, 12);
        
        a.agregarAnimal(pez);
        a.agregarAnimal(delfin);
        a.agregarAnimal(Pulpo);
        a.agregarAnimal(foca);
        //mostrar todos los animales
        a.mostrarAnimales();
        
        //exception de animal repetido
        try{
            a.agregarAnimal(new Peces("Nemo", "Tanque Tropical", TipoAgua.DULCE, 12.3));
        } catch (AnimalDuplicadoException e){
            System.out.println("Exception " + e.getMessage());
        }
        
        a.nadar();
        
        a.mostrarAnimalesPorTipo("MamiferosMarinos");
        
    }
}
