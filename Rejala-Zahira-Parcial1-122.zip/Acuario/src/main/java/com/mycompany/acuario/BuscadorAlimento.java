
package com.mycompany.acuario;

public interface BuscadorAlimento {
    void buscarAlimento();
}
