
package com.mycompany.acuario;

public class MamiferosMarinos extends Animal implements Nadador, BuscadorAlimento{
    private int frecuenciaRespiracion;

    public MamiferosMarinos(String nombre, String habitad, TipoAgua tipoAgua, int frecuenciaRespiracion) {
        super(nombre, habitad, tipoAgua);
        this.frecuenciaRespiracion = frecuenciaRespiracion;
    }
    
    public int getFrecuenciaRespiracion(){
        return frecuenciaRespiracion;
    }

    @Override
    public void Nadar() {
        System.out.println("Mi nombre es " + getNombre() + " y estoy nadando");
    }

    @Override
    public void buscarAlimento() {
        System.out.println("Mi nombre es " + getNombre() + " y estoy buscando alimento");
    }

    @Override
    public String toString() {
        return super.toString() + "Caracteristica de Mamiferos Marinos{" + "frecuenciaRespiracion=" + frecuenciaRespiracion + '}';
    }
    
    
    
}
