
package com.mycompany.acuario;

import java.util.Objects;


public abstract class Animal {
    private String nombre;
    private String habitad;
    private TipoAgua tipoAgua;

    public Animal(String nombre, String habitad, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.habitad = habitad;
        this.tipoAgua = tipoAgua;
    }
    
    
    public String getNombre(){
        return nombre;
    }
    
    public String getHabitad(){
        return habitad;
    }
    
    public TipoAgua getTipoAgua(){
        return tipoAgua;
    }

    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", habitad=" + habitad + ", tipoAgua=" + tipoAgua + '}';
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, tipoAgua);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Animal other = (Animal) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.habitad, other.habitad)) {
            return false;
        }
        return this.tipoAgua == other.tipoAgua;
    }
    
    
    
}
