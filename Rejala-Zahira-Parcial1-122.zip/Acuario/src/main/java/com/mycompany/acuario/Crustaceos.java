
package com.mycompany.acuario;

public class Crustaceos extends Animal implements BuscadorAlimento{
    private int numeroPatas;

    public Crustaceos(String nombre, String habitad, TipoAgua tipoAgua, int numeroPatas) {
        super(nombre, habitad, tipoAgua);
        this.numeroPatas = numeroPatas;
    }

    public int getNumeroPatas(){
        return numeroPatas;
    }
    
    @Override
    public void buscarAlimento() {
        System.out.println("Mi nombre es " + getNombre() + " y buscando alimento");
    }

    @Override
    public String toString() {
        return super.toString() + "Caracteristica de Crustaceos{" + "numeroPatas=" + numeroPatas + '}';
    }
    
    
    
}
